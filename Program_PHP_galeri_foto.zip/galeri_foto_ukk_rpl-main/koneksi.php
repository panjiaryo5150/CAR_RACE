<?php 
$conn=mysqli_connect("localhost", "root", "", "latihan_ukk");
?>